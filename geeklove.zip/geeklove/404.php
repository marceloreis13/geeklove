<?php get_header(); ?>

<div class="container error-404 center">
    <h1>Error 404 - Not Found</h1>
</div>


<?php get_footer(); ?>