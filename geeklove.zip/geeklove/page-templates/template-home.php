<?php
/*
Template Name: Home
*/
?>
<?php get_header(); ?>
<div class="homepage-sections">
    <?php dynamic_sidebar('sidebar-homepage') ?>
</div>
<?php get_footer(); ?>