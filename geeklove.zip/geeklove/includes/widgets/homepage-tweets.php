<?php
add_action('widgets_init', create_function('', 'return register_widget("stag_wedding_tweets");'));

class stag_wedding_tweets extends WP_Widget{
  function stag_wedding_tweets(){
    $widget_ops = array('classname' => 'wedding-couple-tweets', 'description' => __('Display back to back tweets from bridegroom and bride.', 'stag'));
    $control_ops = array('width' => 300, 'height' => 350, 'id_base' => 'stag_wedding_tweets');
    $this->WP_Widget('stag_wedding_tweets', __('Homepage: Wedding Couple Tweets', 'stag'), $widget_ops, $control_ops);
  }

  function widget($args, $instance){
    extract($args);

    // VARS FROM WIDGET SETTINGS
    $title = apply_filters('widget_title', $instance['title'] );
    $subtitle = $instance['subtitle'];
    $brg_twitter = $instance['brg_twitter'];
    $br_twitter = $instance['br_twitter'];

    $cache_time = $instance['cache_time'];
    $postcount = $instance['postcount'];

    echo $before_widget;

    $id = rand(0,999);
    ?>

    <!-- BEGIN #tweets -->
    <section id="tweets" class="section-block">

        <div class="inner-block">
            <h2 class="section-title"><?php echo $title; ?></h2>
            <?php if($subtitle != '') echo "<h4 class='sub-title'>$subtitle</h4>"; ?>
            
            <div class="grids">
              

              <?php
                $stag_options = get_option( 'stag_options' );

                if( empty($stag_options['consumer_key']) || empty($stag_options['consumer_secret']) || empty($stag_options['access_key']) || empty($stag_options['access_secret']) ) {
                  echo '<strong>' . __( 'Please fill all widget settings.', 'stag' ) . '</strong>' . $after_widget;
                  return;
                }

                $tw_helper = new StagTWHelper();

                $last_cache = get_option('twitter_widget_last_cache_time');
                $diff = time() - $last_cache;
                $crt = $instance['cache_time'] * 3600;

                if( $diff >= $crt || empty($last_cache) ){
                  $connection = $tw_helper->getConnectionWithAccessToken( $stag_options['consumer_key'], $stag_options['consumer_secret'], $stag_options['access_key'], $stag_options['access_secret'] );
                  
                  $brg_tweets = $connection->get( "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=" . $instance['brg_twitter'] . "&count=". $instance['postcount'] ) or die( __( "Couldn't retrieve tweets! Wrong username!", "stag" ) );
                  $br_tweets  = $connection->get( "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=" . $instance['br_twitter'] . "&count=". $instance['postcount'] ) or die( __( "Couldn't retrieve tweets! Wrong username!", "stag" ) );

                  if(!empty($brg_tweets->errors) && !empty($br_tweets->errors) ){
                    if($brg_tweets->errors[0]->message == 'Invalid or expired token'){
                      echo '<strong>'.$brg_tweets->errors[0]->message.'!</strong><br />You\'ll need to regenerate it <a href="https://dev.twitter.com/apps" target="_blank">here</a>!' . $after_widget;
                    }else{
                      echo '<strong>'.$brg_tweets->errors[0]->message.'</strong>' . $after_widget;
                    }
                    return;
                  }

                  for($i = 0;$i <= count($brg_tweets); $i++){
                    if(!empty($brg_tweets[$i])){
                      $brg_tweets_array[$i]['created_at'] = $brg_tweets[$i]->created_at;
                      $brg_tweets_array[$i]['text'] = $brg_tweets[$i]->text;
                      $brg_tweets_array[$i]['status_id'] = $brg_tweets[$i]->id_str;
                    }
                  }

                  for($i = 0;$i <= count($br_tweets); $i++){
                    if(!empty($br_tweets[$i])){
                      $br_tweets_array[$i]['created_at'] = $br_tweets[$i]->created_at;
                      $br_tweets_array[$i]['text'] = $br_tweets[$i]->text;
                      $br_tweets_array[$i]['status_id'] = $br_tweets[$i]->id_str;
                    }
                  }

                  update_option('twitter_widget_brg_tweets', serialize($brg_tweets_array));
                  update_option('twitter_widget_br_tweets', serialize($br_tweets_array));
                  update_option('twitter_widget_last_cache_time', time());

                }

                $brg_widget_tweets = maybe_unserialize(get_option('twitter_widget_brg_tweets'));
                $br_widget_tweets = maybe_unserialize(get_option('twitter_widget_br_tweets'));

                  ?>

                  <div class="grid-6 tweets">
                    <div class="tweet-header">
                      <?php if(stag_get_option('wedding_bride_avatar') != ''): ?>
                        <img src="<?php echo stag_get_option('wedding_bride_avatar'); ?>" alt="" class="avatar-tw">
                      <?php endif; ?>

                      <h4><?php echo stag_get_option('wedding_bride_first_name'); ?></h4><span><a href="//twitter.com/<?php echo $br_twitter; ?>">@<?php echo $br_twitter; ?></a></span>
                    </div>

                    <?php
                      if( !empty($br_widget_tweets) ){
                        echo '<ul>';
                        $count = 1;
                        $protocol = is_ssl() ? 'https:' : 'http:';
                        foreach( $br_widget_tweets as $tweet ){
                          echo '<li><span>'. $tw_helper->twitter_widget_convert_links($tweet['text']) .'</span><div class="time"><a href="'.$protocol.'//twitter.com/'.$instance['br_twitter'].'/statuses/'.$tweet['status_id'].'" target="_blank">'.$tw_helper->twitter_widget_relative_time($tweet['created_at']).'</a></div></li>';
                          if( $count == $instance['postcount']){ break; }
                          $count++;
                        }
                        echo '</ul>';
                      }
                    ?>  

                    <div class="follow">
                      <a href="//twitter.com/<?php echo $br_twitter; ?>" class="button">Follow</a>
                    </div>
                  </div>

                  <div class="grid-6 tweets">
                    <div class="tweet-header">
                      <?php if(stag_get_option('wedding_bridegroom_avatar') != ''): ?>
                        <img src="<?php echo stag_get_option('wedding_bridegroom_avatar'); ?>" alt="" class="avatar-tw">
                      <?php endif; ?>

                      <h4><?php echo stag_get_option('wedding_bridegroom_first_name'); ?></h4><span><a href="//twitter.com/<?php echo $brg_twitter; ?>">@<?php echo $brg_twitter; ?></a></span>
                    </div>

                    <?php
                      if( !empty($brg_widget_tweets) ){
                        echo '<ul>';
                        $count = 1;
                        $protocol = is_ssl() ? 'https:' : 'http:';
                        foreach( $brg_widget_tweets as $tweet ){
                          echo '<li><span>'. $tw_helper->twitter_widget_convert_links($tweet['text']) .'</span><div class="time"><a href="'.$protocol.'//twitter.com/'.$instance['brg_twitter'].'/statuses/'.$tweet['status_id'].'" target="_blank">'.$tw_helper->twitter_widget_relative_time($tweet['created_at']).'</a></div></li>';
                          if( $count == $instance['postcount']){ break; }
                          $count++;
                        }
                        echo '</ul>';
                      }
                    ?>  

                    <div class="follow">
                      <a href="//twitter.com/<?php echo $brg_twitter; ?>" class="button">Follow</a>
                    </div>
                  
                  </div>

            </div>
            <!-- END .inner-block -->
        </div>
        <!-- END #tweets -->
    </section>

    <?php
    echo $after_widget;
  }

  function update($new_instance, $old_instance){
    $instance = $old_instance;

    // STRIP TAGS TO REMOVE HTML
    $instance['title'] = strip_tags($new_instance['title']);
    $instance['subtitle'] = strip_tags($new_instance['subtitle']);
    $instance['brg_twitter'] = strip_tags($new_instance['brg_twitter']);
    $instance['br_twitter'] = strip_tags($new_instance['br_twitter']);

    $instance['postcount'] = strip_tags($new_instance['postcount']);

    $instance['consumer_key'] = strip_tags($new_instance['consumer_key']);
    $instance['consumer_secret'] = strip_tags($new_instance['consumer_secret']);
    $instance['access_token'] = strip_tags($new_instance['access_token']);
    $instance['access_token_secret'] = strip_tags($new_instance['access_token_secret']);
    $instance['cache_time'] = strip_tags($new_instance['cache_time']);

    return $instance;
  }

  function form($instance){
    $defaults = array(
      'title' => 'Tweets Back to Back',
      'subtitle' => '',
      'brg_twitter' => '',
      'postcount' => 3,
      'br_twitter' => '',
      'cache_time' => ''
      );

    $instance = wp_parse_args((array) $instance, $defaults);

    /* HERE GOES THE FORM */
    ?>
    <p>
      <span class="description">This widget will use avatar and first name of bride and bridegroom set under Theme Options > <a href="<?php echo admin_url('admin.php?page=stagframework#wedding-settings'); ?>">Wedding Settings</a>.</span>
    </p>
    <p></p>

    <p>
      <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'stag'); ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('subtitle'); ?>"><?php _e('Sub Title:', 'stag'); ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'subtitle' ); ?>" name="<?php echo $this->get_field_name( 'subtitle' ); ?>" value="<?php echo $instance['subtitle']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('brg_twitter'); ?>"><?php _e('Bridegroom Twitter Username:', 'stag'); ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'brg_twitter' ); ?>" name="<?php echo $this->get_field_name( 'brg_twitter' ); ?>" value="<?php echo $instance['brg_twitter']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('br_twitter'); ?>"><?php _e('Bride Twitter Username:', 'stag'); ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'br_twitter' ); ?>" name="<?php echo $this->get_field_name( 'br_twitter' ); ?>" value="<?php echo $instance['br_twitter']; ?>" />
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('cache_time'); ?>"><?php _e('Cache tweets in every:', 'stag'); ?></label>
      <input type="text" class="small-text" id="<?php echo $this->get_field_id( 'cache_time' ); ?>" name="<?php echo $this->get_field_name( 'cache_time' ); ?>" value="<?php echo $instance['cache_time']; ?>" />
      <?php _e('hours', 'stag'); ?>
    </p>

    <p>
      <label for="<?php echo $this->get_field_id('postcount'); ?>"><?php _e('Number of tweets (max 10):', 'stag'); ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'postcount' ); ?>" name="<?php echo $this->get_field_name( 'postcount' ); ?>" value="<?php echo $instance['postcount']; ?>" />
    </p>

    <p>
      <span class="description"><?php _e('Details like Consumer key and secret can be set under <a href="'. admin_url('options-general.php?page=stagtools') .'" target="_blank">StagTools Settings</a>', 'stag'); ?></span>
    </p>

    <?php
  }

}